package com.sanchit.pilluassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class PilluAccessibilityService : AccessibilityService() {

    companion object {
        var instance: PilluAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // पुढच्या version मध्ये screen-reading आणि UI actions येथे जोडू.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
