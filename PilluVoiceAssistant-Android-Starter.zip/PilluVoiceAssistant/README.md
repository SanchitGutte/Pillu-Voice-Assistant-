# Pillu Voice Assistant — Android starter

हा starter project:
- Marathi speech-to-text
- Text-to-speech
- YouTube / WhatsApp / Google / Settings उघडणे
- Back action साठी Accessibility Service
- पुढे AI brain आणि अधिक Android actions जोडण्यासाठी structure

## Build
Android Studio मध्ये project उघडा आणि Run करा.

## Accessibility
App उघडल्यानंतर "Accessibility Access उघडा" दाबा आणि Pillu Assistant enable करा.

## पुढचा टप्पा
AI API जोडण्यासाठी API key थेट APK मध्ये ठेवू नका. Backend/proxy वापरा.
